import os
os.environ["KERAS_BACKEND"] = "tensorflow"
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt

import math
from keras.layers import Input, Conv2D
from keras.models import Model, Sequential
from keras.layers.core import Reshape, Dense, Dropout, Flatten
from keras.layers.advanced_activations import LeakyReLU
from keras.layers.convolutional import Convolution2D, UpSampling2D
from keras.layers.normalization import BatchNormalization
from keras.datasets import mnist
from keras.optimizers import Adam
from keras import backend as K
from keras import initializers
from keras.utils.vis_utils import plot_model
import tensorflow as tf

K.set_image_data_format('channels_first')

np.random.seed(1000)

randomDim = 100

num_labels = 100
grid_size = 100
latent_size = 100

(X_train, y_train), (X_test, y_test) = mnist.load_data()
X_train = (X_train.astype(np.float32) - 127.5)/127.5
X_train = X_train.reshape(60000, 784)

adam = Adam(lr=0.0002, beta_1=0.5)

generator = Sequential()
generator.add(Dense(256, input_dim=randomDim, kernel_initializer=initializers.RandomNormal(stddev=0.02)))
generator.add(BatchNormalization())
generator.add(LeakyReLU(0.2))

generator.add(Dense(512))
generator.add(BatchNormalization())
generator.add(LeakyReLU(0.2))

generator.add(Dense(1024))
generator.add(BatchNormalization())
generator.add(LeakyReLU(0.2))

generator.add(Dense(784, activation='tanh'))
generator.compile(loss='binary_crossentropy', optimizer=adam)

plot_model(generator, to_file='generator_plot.png', show_shapes=True, show_layer_names=True)

discriminator = Sequential()
discriminator.add(Dense(1024, input_dim=784, kernel_initializer=initializers.RandomNormal(stddev=0.02)))
discriminator.add(LeakyReLU(0.2))
discriminator.add(Dropout(0.3))
discriminator.add(Dense(512))
discriminator.add(LeakyReLU(0.2))
discriminator.add(Dropout(0.3))
discriminator.add(Dense(256))
discriminator.add(LeakyReLU(0.2))
discriminator.add(Dropout(0.3))
discriminator.add(Dense(1, activation='sigmoid'))
discriminator.compile(loss='binary_crossentropy', optimizer=adam)
plot_model(discriminator, to_file='discriminator_plot.png', show_shapes=True, show_layer_names=True)
# Combined network
discriminator.trainable = False
ganInput = Input(shape=(randomDim,))
x = generator(ganInput)
ganOutput = discriminator(x)
gan = Model(inputs=ganInput, outputs=ganOutput)
gan.compile(loss='binary_crossentropy', optimizer=adam)

plot_model(gan, to_file='gan_plot.png', show_shapes=True, show_layer_names=True)

dLosses = []
gLosses = []


def plotLoss(epoch):
    plt.figure(figsize=(10, 8))
    plt.plot(dLosses, label='Discriminitive loss')
    plt.plot(gLosses, label='Generative loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.savefig('gan_loss_epoch_%d.png' % epoch)


def plotGeneratedImages(epoch, examples=100, dim=(10, 10), figsize=(10, 10)):
    noise = np.random.normal(0, 1, size=[examples, randomDim])
    generatedImages = generator.predict(noise)
    generatedImages = generatedImages.reshape(examples, 28, 28)

    plt.figure(figsize=figsize)
    for i in range(generatedImages.shape[0]):
        plt.subplot(dim[0], dim[1], i+1)
        plt.imshow(generatedImages[i], interpolation='nearest', cmap='gray_r')
        plt.axis('off')
    plt.tight_layout()
    plt.savefig('gan_generated_image_epoch_%d.png' % epoch)

def saveModels(epoch):
    generator.save('gan_generator_epoch_%d.h5' % epoch)
    discriminator.save('gan_discriminator_epoch_%d.h5' % epoch)

def plot_images(generator, noise_input, noise_labels, tag, step=0):
    os.makedirs(tag, exist_ok=True)
    images = generator.predict([noise_input, noise_labels])
    plt.figure(figsize=(10, 7))
    dim = (10, 10)
    num_images = images.shape[0]
    image_size = images.shape[1]
    #rows = int(math.sqrt(noise_input.shape[0]))
    for i in range(100):
        plt.subplot(dim[0], dim[1], i + 1)
        image = np.reshape(images[i], [28, 28])
        plt.imshow(image, interpolation='nearest', cmap='gray_r')
        plt.axis('off')
    plt.savefig('res_test1.png')
    plt.close()

def test_gan(generator, class_label=None):
    tag = "test_outputs"
    noise_input = np.random.uniform(-1.2, 1.2, size=[grid_size, latent_size])
    step = 0
    if class_label is None:
        noise_class = np.eye(num_labels)[np.random.choice(num_labels, grid_size)]
    else:
        noise_class = np.zeros((grid_size, num_labels))
        noise_class[:, class_label] = 2
        step = class_label
    plot_images(generator,
                tag=tag,
                noise_input=noise_input,
                noise_labels=noise_class,
                step=step)
    print('\n')
    print(tag, " Метки для генерируемых изображений: ", np.argmax(noise_class, axis=1))


def train(epochs=1, batchSize=128):
    batchCount = int(X_train.shape[0] / batchSize)
    print('Epochs:', epochs)
    print('Batch size:', batchSize)
    print('Batches per epoch:', batchCount)

    for e in range(1, epochs+1):
        print('-'*15, 'Epoch %d' % e, '-'*15)
        for _ in tqdm(range(batchCount)):
            noise = np.random.normal(0, 1, size=[batchSize, randomDim])
            imageBatch = X_train[np.random.randint(0, X_train.shape[0], size=batchSize)]

            generatedImages = generator.predict(noise)
            X = np.concatenate([imageBatch, generatedImages])

            yDis = np.zeros(2*batchSize)
            yDis[:batchSize] = 0.9

            discriminator.trainable = True
            dloss = discriminator.train_on_batch(X, yDis)

            noise = np.random.normal(0, 1, size=[batchSize, randomDim])
            yGen = np.ones(batchSize)
            discriminator.trainable = False
            gloss = gan.train_on_batch(noise, yGen)

        dLosses.append(dloss)
        gLosses.append(gloss)

        if e == 1 or e % 50 == 0:
            plotGeneratedImages(e)
            saveModels(e)

    plotLoss(e)

if __name__ == '__main__':
    #train(250, 256)
    m = tf.keras.models.load_model("gan_generator_epoch_300.h5");
    test_gan(m)