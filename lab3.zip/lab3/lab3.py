import numpy as np
import pandas as pd
import math
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.metrics import r2_score, mean_squared_error

# Кол-во данных
size = 100

sigma = 2.59
gamma = 2.55

# Вычисление функции
def u(x):
    return x - 3 * np.exp(-1 * np.power(x, 2) / 0.15) + np.exp(-1 * np.power(x - 1, 2) / 0.1)

# Вычисление Гауссова ядра (с помощью функции)
def RBF(x):
    K = 1.0 * rbf_kernel(x, gamma = sigma)
    return K

# Вычисление Гауссова ядра (вручную)
def RBF1(x, z):
    K = np.exp(-np.pow(np.linalg.norm((x - z), ord=1), 2) / 2 * np.pow(sigma, 2))
    return K

# Вычисление предсказания по модели
def predict(alfa, x, beta):
    return np.dot(alpha, RBF(x)) + beta


# Задаем границы
l_b = -1
h_b = 2

# Генерируем массив значений
x = np.linspace(l_b, h_b, size).reshape(-1, 1)

# Вычиляем значения функции
y_ist = u(x)

# Вычиляем значения функции с шумами
gaussian_noise = np.random.normal(0, 0.5, size).reshape(-1,1)
y = y_ist + gaussian_noise

# Выводим на консоль
print('x=\n', x)
print('y_ist=\n', y_ist)
print('y=\n', y)

# Выводим в файл
df = pd.DataFrame({'x': x.ravel(), 'y_ist': y_ist.ravel(), 'y': y.ravel()})
df.to_excel("D:/Магистратура/Попов/lab3/lab3.xlsx")

# Строим графики
plt.scatter(x, y_ist, c='b', alpha=0.5, label="Наблюдения")
plt.plot(x, y_ist, 'r', lw=3, label='Исходная функция', alpha=0.8)
plt.legend()
plt.show()

# Строим графики
plt.scatter(x, y, c='b', alpha=0.5, label="Наблюдения")
plt.plot(x, y_ist, 'r', lw=3, label='Исходная функция', alpha=0.8)
plt.legend()
plt.show()

# ВЫЧИСЛЕНИЕ МОДЕЛИ
# Представление в виде столбца
y = y[:, np.newaxis]
Ones = np.array([[1]] * len(y))
K = RBF(x)
A_cross = np.linalg.pinv(np.block([
    [0, Ones.T],
    [Ones, K + 1.0 / gamma * np.identity(len(y))]
]))

B = np.concatenate(([0], y), axis=None)

solution = np.dot(A_cross, B)

beta = solution[0]
alpha = solution[1:]
print('beta=\n', beta)
print('alpha=\n', alpha)
print('K=\n', K)
# Вычисление y по модели
y_predict = predict(alpha, x, beta)
print('y_predict=\n', y_predict)

plt.plot(x, y_ist, 'r', lw=3, label='Исходная функция', alpha=0.8)
plt.plot(x, y_predict, 'b', lw=3, label='LS SVM', alpha=0.8)
plt.legend()
plt.show()

mse = mean_squared_error(y_ist, y_predict)
r2 = r2_score(y_ist, y_predict)
print('MSE=\n', format(mse, '.8f'))
print('R2=\n', format(r2, '.8f'))