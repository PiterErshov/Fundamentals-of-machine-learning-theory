import numpy as np
import matplotlib.pyplot as plt
import random
import math
from collections import namedtuple
import csv


# регрессоры-тета
# X-Матрица len(x) X len(teta)

def p(z, c):
    if abs(z) < c:
        return (z ** 6) / (6 * c ** 4) - (z ** 4) / (2 * c ** 2) + (z ** 2) / 2
    else:
        return (c ** 6) / 6


def w(z, c):
    if abs(z) < c:
        return (1 - (z / c) ** 2) ** 2
    else:
        return 0


def model(x, teta):
    return (x ** 3) * teta[0] + (x ** 2) * teta[1] + x * teta[2] + 7


def get_noisy_sample(y, noise_value):
    noise = np.random.normal(0, 1, len(y))
    outline_number = int(len(y) * noise_value)

    outline_values = []
    noisy_sample = np.copy(y)
    for i in range(0, outline_number):
        index = random.randint(0, len(y) - 1)
        noisy_sample[index] = noisy_sample[index] + noise[index] * 10

    return noisy_sample


def mnk(x, y):
    n = len(y)
    sum_x4 = sum([x_ ** 4 for x_ in x])
    sum_x3 = sum([x_ ** 3 for x_ in x])
    sum_x2 = sum([x_ ** 2 for x_ in x])
    sum_x = sum(x)
    sum_x2y = sum([x[i] ** 2 * y[i] for i in range(len(x))])
    sum_xy = sum([x[i] * y[i] for i in range(len(x))])
    sum_y = sum(y)

    A = np.array([[sum_x4, sum_x3, sum_x2],
                  [sum_x3, sum_x2, sum_x],
                  [sum_x2, sum_x, n]])
    B = np.array([sum_x2y, sum_xy, sum_y])

    return np.linalg.solve(A, B)


def imnk(x, y, funcs, teta, stdev, c):
    prev_teta = teta
    r = np.array(np.zeros(len(x)))

    W = np.array(np.zeros(shape=(len(x), len(x))))
    X = np.array(np.zeros(shape=(len(x), len(teta))))
    for i in range(len(x)):
        for j in range(len(teta)):
            X[i][j] = funcs[j](x[i])

    solution_is_found = False
    delta = 0.000001
    k = 0
    while not solution_is_found:
        for i in range(len(x)):
            r[i] = y[i] - model(x[i], teta)
            W[i][i] = w(r[i] / stdev, c)

        prev_teta = teta

        teta = np.linalg.inv(np.transpose(X) @ W @ X) @ np.transpose(X) @ W @ y
        stdev = np.median(np.abs(r)) / 0.67449
        k += 1

        max_v = 0
        for i in range(len(teta)):
            if abs((teta[i] - prev_teta[i]) / teta[i]) > max_v:
                max_v = abs((teta[i] - prev_teta[i]) / teta[i])

        if max_v < delta:
            solution_is_found = True

    return np.array(teta), stdev


def get_MSE(y_true, y_pred):
    return np.sqrt(np.mean((-y_true + y_pred) ** 2))


funcs = [lambda x: x ** 3, lambda x: x **2, lambda x: x]
true_teta = np.array([-0.1, 0.3, 0.5, 0.7])

def f(x):
    return np.array([np.ones(len(x)), np.array(x), np.array(x * x), np.array(x * x * x)]).T

x = np.linspace(-1, 1, 100)
r = np.array([model(x_, true_teta) for x_ in x])
y = np.dot(f(x), true_teta);

noise_percents = [0.01, 0.05, 0.1, 0.15, 0.2, 0.25]
noisy_samples = []
for i in range(0, len(noise_percents)):
    noisy_samples.append(get_noisy_sample(y, noise_percents[i]))

# plt.plot(x, y, 'c', label='Data')
# plt.plot(x, noisy_samples[0], 'm', label='Noisy data')
# plt.legend(loc='upper right')
# plt.show()

ResInfo = namedtuple('ResInfo', 'noise c imnk_teta_dif imnk_mse mnk_teta_dif mnk_mse mad')
results = []

stdev_values = [0.1, 0.2]
c_values = [4.685, 6, 7.315, 8.63, 9.945, 10, 14, 26]

for i in range(0, len(noisy_samples)):
    for c in c_values:
        for stdev in stdev_values:
            teta_imnk, mad = imnk(x, noisy_samples[i], funcs, true_teta, stdev, c)

            y_pred_imnk = np.array(np.zeros(len(x)))
            for j in range(len(x)):
                r[j] = model(x[j], teta_imnk)
                y_pred_imnk[j] = model(x[j], teta_imnk)
            imnk_dif = np.asscalar(
                np.transpose(np.reshape(teta_imnk - true_teta, (len(true_teta), 1))) @ np.reshape(teta_imnk - true_teta,
                                                                                                  (len(true_teta), 1)))
            imnk_mse = get_MSE(y, y_pred_imnk)

            teta_mnk = mnk(x, noisy_samples[i])
            y_pred_mnk = np.array(np.zeros(len(x)))
            for j in range(len(x)):
                r[j] = model(x[j], teta_mnk)
                y_pred_mnk[j] = model(x[j], teta_mnk)
            mnk_dif = np.asscalar(
                np.transpose(np.reshape(teta_mnk - true_teta, (len(true_teta), 1))) @ np.reshape(teta_mnk - true_teta,
                                                                                                 (len(true_teta), 1)))
            mnk_mse = get_MSE(y, y_pred_mnk)

            results.append(ResInfo(noise_percents[i], c, imnk_dif, imnk_mse, mnk_dif, mnk_mse, mad))

            plt.plot(x, y, 'c', label='y')
            plt.plot(x, y_pred_imnk, 'm', label=r'$\bar y$')
            plt.plot(x, y - y_pred_imnk, 'g', label=r'$y - \bar y$')
            plt.legend(loc='upper right')
            plt.savefig("data_with_{}_noise.png".format(noise_percents[i] * 100))
            plt.clf()

            plt.plot(x, y, '.', label='y')
            plt.plot(x, y_pred_imnk, 'c', label='М-оценка')
            plt.plot(x, y_pred_mnk, 'c--', label='МНК-оценка')
            plt.legend(loc='upper right')
            plt.savefig("m_mnk_estimate_{}_noise.png".format(noise_percents[i] * 100))
            plt.clf()

for r in results:
    print(r)

print(np.random.normal(0, 0.01, len(x)))