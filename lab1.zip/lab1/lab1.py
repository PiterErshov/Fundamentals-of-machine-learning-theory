import numpy as p
from numpy import matrix
from numpy import linalg

X1 = matrix([[4.44, 1, 0, 1, 0, 0],
             [4.44, 1, 0, 0, 1, 0],
             [4.44, 1, 0, 0, 0, 1],
             [4.44, 1, 0, 0, 0, 0],
             [4.44, 0, 1, 1, 0, 0],
             [4.44, 0, 1, 0, 1, 0],
             [4.44, 0, 1, 0, 0, 1],
             [4.44, 0, 1, 0, 0, 0],
             [4.44, 0, 0, 1, 0, 0],
             [4.44, 0, 0, 0, 1, 0],
             [4.44, 0, 0, 0, 0, 1],
             [4.44, 0, 0, 0, 0, 0]])

print(X1)
X2 = matrix([[0, 0],
             [0, 0],
             [0, 0],
             [0, 1],
             [0, 0],
             [0, 0],
             [0, 0],
             [0, 1],
             [1, 0],
             [1, 0],
             [1, 0],
             [1, 1]])
print(X2)

y1 = matrix([7.14, 4.11, 8.13, 4.07, 3.10,	0, 4.03, 0.02, 7.09, 4.11, 8.12, 4.07])
print(y1)
y2 = matrix([6.90, 3.95, 7.97, 3.99, 2.91, 0.01, 3.98, 0, 6.92, 3.96, 8.01, 4.00])
print(y2)
y3 = matrix([7.02, 4.03, 8.05, 4.03, 3.01, 0.01, 4.01, 0.01, 7.01, 4.04, 8.07, 4.04])

A_ = (X1.T * X1).I * X1.T * X2
print("A_:")
A_l = A_.shape
for i in range(A_l[0]):
    for j in range(A_l[1]):
        print("%.4f" % A_[i, j], end=' ')
    print("\n")

print("Проверка:")
Pr = X1 * A_
print(Pr)

print("Оценки тетта1:")
theta1 = (X1.T * X1).I * X1.T * y1.T
for i in range(theta1.shape[0]):
    print("%.2f" % theta1[i])

print("Оценки тетта2:")
theta2 = (X1.T * X1).I * X1.T * y2.T
for i in range(theta2.shape[0]):
    print("%.2f" % theta2[i])

print("Оценки тетта:")
theta = (X1.T * X1).I * X1.T * y3.T
for i in range(theta.shape[0]):
    print("%.2f" % theta[i])
