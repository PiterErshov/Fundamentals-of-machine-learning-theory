import numpy as np
import matplotlib.pyplot as plt

from keras.models import Model, model_from_json
from keras.layers import Dense, Dropout, Activation, Flatten, Conv2D, MaxPooling2D, UpSampling2D, Input, LSTM, RepeatVector
from keras.datasets import mnist
from keras.utils.vis_utils import plot_model

(X_train, _), (X_test, _) = mnist.load_data()
shape_x = 28
shape_y = 28

X_ist = X_test.astype('float32') / 255.
X_ist = X_test.reshape(-1,shape_x,shape_y,1)

X_train=X_train.astype('float32')/255
X_test=X_test.astype('float32')/255
X_train=np.reshape(X_train,(len(X_train),28,28,1))
X_test=np.reshape(X_test,(len(X_test),28,28,1))
noise_factor = 0.5
X_train = X_train + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=X_train.shape)
X_test = X_test + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=X_test.shape)
X_train = np.clip(X_train, 0., 1.)
X_test = np.clip(X_test, 0., 1.)

n=5
plt.imshow(X_ist[5].reshape(28,28), interpolation='nearest', cmap='gray_r')
plt.gray()
plt.show()
for i in range(n):
    plt.imshow(X_test[i].reshape(28,28), interpolation='nearest', cmap='gray_r')
    plt.gray()
    plt.show()
    input_img = Input(shape=(shape_x, shape_y, 1))

# Ecoding
x = Conv2D(32, (3, 3), padding='same', activation='relu')(input_img)
x = MaxPooling2D(pool_size=(2,2), padding='same')(x)
x = Conv2D(1,(3, 3), padding='same', activation='relu')(x)
encoded = MaxPooling2D(pool_size=(2,2), padding='same')(x)

# Decoding
x = Conv2D(1,(3, 3), padding='same', activation='relu')(encoded)
x = UpSampling2D((2, 2))(x)
x = Conv2D(32,(3, 3), padding='same', activation='relu')(x)
x = UpSampling2D((2, 2))(x)
x = Conv2D(1,(3, 3), padding='same')(x)

decoded = Activation('linear')(x)

autoencoder = Model(input_img, decoded)
autoencoder.compile(optimizer='adadelta', loss='mean_squared_error')
autoencoder.summary()
#plot_model(autoencoder, to_file='autoencoder_plot.png', show_shapes=True, show_layer_names=True)

autoencoder.fit(X_train, X_train, epochs = 20, batch_size = 64, validation_split = 0.1)

# Save autoencoder weight
json_string = autoencoder.to_json()
autoencoder.save_weights('autoencoder.h5')
open('autoencoder.h5', 'w').write(json_string)

encoder = Model(inputs = input_img, outputs = encoded)
#plot_model(encoder, to_file='encoder_plot.png', show_shapes=True, show_layer_names=True)
X_train_enc = encoder.predict(X_train)

encoded_imgs = encoder.predict(X_test)
decoded_imgs = autoencoder.predict(X_test)

n = 10
plt.figure(figsize=(20, 4))

for i in range(n):
    # display original
    ax = plt.subplot(3, n, i + 1)
    plt.imshow(X_ist[i].reshape(28, 28), interpolation='nearest', cmap='gray_r')
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

    # Encoded images
    ax = plt.subplot(3, n, i + 1 + n)
    plt.imshow(X_test[i].reshape(28, 28), interpolation='nearest', cmap='gray_r')
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)


    # display reconstruction
    ax = plt.subplot(3, n, i + 1 + 2*n)
    plt.imshow(decoded_imgs[i].reshape(28, 28), interpolation='nearest', cmap='gray_r')
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

plt.show()
